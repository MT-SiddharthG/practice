# Minesweeper
A copy of legendary minesweeper game from Microsoft.
This mini project is copied, learned and edited for learning the concept of Class and OOP concepts with tkinter framework of python.
This project was originally created by JimShapedCoding and link to the project is 
https://www.youtube.com/playlist?list=PLOkVupluCIjsyLs2lHL7M3ZubAxH10WHB
Channel Link : https://www.youtube.com/playlist?list=PLOkVupluCIjsyLs2lHL7M3ZubAxH10WHB
